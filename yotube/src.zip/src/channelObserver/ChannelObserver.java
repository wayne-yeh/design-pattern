package channelObserver;

import channel.Channel;

public interface ChannelObserver {
    void update(Channel channel);
}
