package com.example.big2.game;

import com.example.big2.card.Card;
import com.example.big2.card.pattern.CardPattern;

import java.util.List;

public class GamePattern {

}
