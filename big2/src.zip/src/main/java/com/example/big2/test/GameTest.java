package com.example.big2.test;

import com.example.big2.game.Game;

public class GameTest {


    public static void main(String[] args) {

        Game game = new Game();
        game.start();
    }
}
