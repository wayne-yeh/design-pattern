package equipment;

public class Telecom {

    public void connect(){
        System.out.println("connect!");
    }

    public void disConnect(){
        System.out.println("disConnect!");
    }
}
