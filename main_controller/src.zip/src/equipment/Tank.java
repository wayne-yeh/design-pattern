package equipment;

public class Tank {

    public void moveForward(){
        System.out.println("tank move forward!");
    }

    public void moveBackward(){
        System.out.println("tank move backward!");
    }
}
