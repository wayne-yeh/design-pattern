package channelObserver;

import channel.Channel;

public interface SubscriberObserver {
    void update(Channel channel);
}
