package map.object.treasure;

import map.object.Character;
import map.object.Treasure;
import map.object.state.OrderlessState;

public class DevilFruit extends Treasure {
    public DevilFruit() {
        super(0.1, new OrderlessState());
    }


}
