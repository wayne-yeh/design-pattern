package map.object;

import map.Object;

public class Obstacle extends Object {
    String symbol = "□";
}
