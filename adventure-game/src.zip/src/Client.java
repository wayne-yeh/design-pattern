import game.Game;
import map.GameMap;
import map.object.Treasure;
import map.object.treasure.*;

import java.util.ArrayList;
import java.util.List;

public class Client {
    public static void main(String[] args) {
        Game game = new Game();
        game.start();
    }
}